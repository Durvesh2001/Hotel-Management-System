import java.time.LocalDate;

public class Reservation {
    private static int COUNTER = 1;
    private final int id;
    private final int roomId;
    private final int guestId;
    private final LocalDate from;
    private final LocalDate to;

    public Reservation(int roomId, int guestId, LocalDate from, LocalDate to) {
        this.id = COUNTER++;
        this.roomId = roomId;
        this.guestId = guestId;
        this.from = from;
        this.to = to;
    }

    public int getId() { return id; }
    public int getRoomId() { return roomId; }
    public int getGuestId() { return guestId; }
    public LocalDate getFrom() { return from; }
    public LocalDate getTo() { return to; }

    @Override
    public String toString() {
        return String.format("Reservation{id=%d, roomId=%d, guestId=%d, from=%s, to=%s}", id, roomId, guestId, from, to);
    }
}
