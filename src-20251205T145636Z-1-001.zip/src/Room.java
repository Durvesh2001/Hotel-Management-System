import java.util.concurrent.atomic.AtomicInteger;

public class Room {
    private static final AtomicInteger COUNTER = new AtomicInteger(100);
    private final int id;
    private String type;
    private double pricePerNight;
    private boolean available;

    public Room(String type, double pricePerNight) {
        this.id = COUNTER.getAndIncrement();
        this.type = type;
        this.pricePerNight = pricePerNight;
        this.available = true;
    }

    public int getId() { return id; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public double getPricePerNight() { return pricePerNight; }
    public void setPricePerNight(double pricePerNight) { this.pricePerNight = pricePerNight; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return String.format("Room{id=%d, type=%s, price=%.2f, available=%s}", id, type, pricePerNight, available);
    }
}
