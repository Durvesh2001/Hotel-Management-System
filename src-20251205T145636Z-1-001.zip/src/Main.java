import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final HotelManagementSystem hms = new HotelManagementSystem();

    public static void main(String[] args) {
        seedData();
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> createRoom();
                    case "2" -> listRooms();
                    case "3" -> updateRoom();
                    case "4" -> deleteRoom();
                    case "5" -> createGuest();
                    case "6" -> listGuests();
                    case "7" -> updateGuest();
                    case "8" -> deleteGuest();
                    case "9" -> createReservation();
                    case "10" -> listReservations();
                    case "11" -> cancelReservation();
                    case "0" -> { running = false; System.out.println("Exiting. Goodbye!"); }
                    default -> System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n--- Hotel Management System ---"); 
        System.out.println("1. Create Room"); 
        System.out.println("2. List Rooms"); 
        System.out.println("3. Update Room"); 
        System.out.println("4. Delete Room"); 
        System.out.println("5. Create Guest"); 
        System.out.println("6. List Guests"); 
        System.out.println("7. Update Guest"); 
        System.out.println("8. Delete Guest"); 
        System.out.println("9. Create Reservation"); 
        System.out.println("10. List Reservations"); 
        System.out.println("11. Cancel Reservation"); 
        System.out.println("0. Exit"); 
        System.out.print("Choose: ");
    }

    // Room operations
    private static void createRoom() {
        System.out.print("Room type (Single/Double/Suite): ");
        String type = scanner.nextLine();
        System.out.print("Price per night: ");
        double price = Double.parseDouble(scanner.nextLine());
        Room r = hms.createRoom(type, price);
        System.out.println("Created: " + r);
    }
    private static void listRooms() {
        List<Room> rooms = hms.listRooms();
        rooms.forEach(System.out::println);
    }
    private static void updateRoom() {
        System.out.print("Room id: ");
        int id = Integer.parseInt(scanner.nextLine());
        System.out.print("New type (leave blank to skip): ");
        String type = scanner.nextLine();
        if (type.isBlank()) type = null;
        System.out.print("New price (-1 to skip): ");
        double price = Double.parseDouble(scanner.nextLine());
        if (price < 0) price = -1;
        System.out.print("Available? (y/n/leave blank): ");
        String av = scanner.nextLine();
        Boolean available = null;
        if (av.equalsIgnoreCase("y")) available = true;
        else if (av.equalsIgnoreCase("n")) available = false;
        boolean ok = hms.updateRoom(id, type, price, available);
        System.out.println(ok ? "Updated." : "Room not found.");
    }
    private static void deleteRoom() {
        System.out.print("Room id: ");
        int id = Integer.parseInt(scanner.nextLine());
        boolean ok = hms.deleteRoom(id);
        System.out.println(ok ? "Deleted." : "Room not found.");
    }

    // Guest operations
    private static void createGuest() {
        System.out.print("Guest name: ");
        String name = scanner.nextLine();
        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        Guest g = hms.createGuest(name, phone, email);
        System.out.println("Created: " + g);
    }
    private static void listGuests() {
        List<Guest> guests = hms.listGuests();
        guests.forEach(System.out::println);
    }
    private static void updateGuest() {
        System.out.print("Guest id: ");
        int id = Integer.parseInt(scanner.nextLine());
        System.out.print("New name (leave blank to skip): ");
        String name = scanner.nextLine(); if (name.isBlank()) name = null;
        System.out.print("New phone (leave blank to skip): ");
        String phone = scanner.nextLine(); if (phone.isBlank()) phone = null;
        System.out.print("New email (leave blank to skip): ");
        String email = scanner.nextLine(); if (email.isBlank()) email = null;
        boolean ok = hms.updateGuest(id, name, phone, email);
        System.out.println(ok ? "Updated." : "Guest not found.");
    }
    private static void deleteGuest() {
        System.out.print("Guest id: ");
        int id = Integer.parseInt(scanner.nextLine());
        boolean ok = hms.deleteGuest(id);
        System.out.println(ok ? "Deleted." : "Guest not found.");
    }

    // Reservation operations
    private static void createReservation() {
        System.out.print("Room id: ");
        int roomId = Integer.parseInt(scanner.nextLine());
        System.out.print("Guest id: ");
        int guestId = Integer.parseInt(scanner.nextLine());
        System.out.print("From (YYYY-MM-DD): ");
        LocalDate from = LocalDate.parse(scanner.nextLine());
        System.out.print("To (YYYY-MM-DD): ");
        LocalDate to = LocalDate.parse(scanner.nextLine());
        Reservation r = hms.createReservation(roomId, guestId, from, to);
        System.out.println(r != null ? "Created: " + r : "Could not create reservation (room not available / invalid ids)." );
    }
    private static void listReservations() {
        List<Reservation> res = hms.listReservations();
        res.forEach(System.out::println);
    }
    private static void cancelReservation() {
        System.out.print("Reservation id: ");
        int id = Integer.parseInt(scanner.nextLine());
        boolean ok = hms.cancelReservation(id);
        System.out.println(ok ? "Canceled." : "Reservation not found.");
    }

    private static void seedData() {
        hms.createRoom("Single", 1000);
        hms.createRoom("Double", 1800);
        hms.createRoom("Suite", 3500);

        Guest g1 = hms.createGuest("Alice", "9991112222", "alice@example.com");
        Guest g2 = hms.createGuest("Bob", "9993334444", "bob@example.com");

        hms.createReservation(100, g1.getId(), LocalDate.now(), LocalDate.now().plusDays(2));
    }
}
