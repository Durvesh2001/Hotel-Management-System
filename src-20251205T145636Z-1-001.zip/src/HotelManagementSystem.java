import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HotelManagementSystem {
    private final List<Room> rooms = new ArrayList<>();
    private final List<Guest> guests = new ArrayList<>();
    private final List<Reservation> reservations = new ArrayList<>();

    // ROOM CRUD
    public Room createRoom(String type, double price) {
        Room r = new Room(type, price);
        rooms.add(r);
        return r;
    }
    public List<Room> listRooms() { return new ArrayList<>(rooms); }
    public Optional<Room> findRoomById(int id) {
        return rooms.stream().filter(r -> r.getId() == id).findFirst();
    }
    public boolean updateRoom(int id, String type, double price, Boolean available) {
        Optional<Room> o = findRoomById(id);
        if (o.isEmpty()) return false;
        Room r = o.get();
        if (type != null) r.setType(type);
        if (price >= 0) r.setPricePerNight(price);
        if (available != null) r.setAvailable(available);
        return true;
    }
    public boolean deleteRoom(int id) {
        return rooms.removeIf(r -> r.getId() == id);
    }

    // GUEST CRUD
    public Guest createGuest(String name, String phone, String email) {
        Guest g = new Guest(name, phone, email);
        guests.add(g);
        return g;
    }
    public List<Guest> listGuests() { return new ArrayList<>(guests); }
    public Optional<Guest> findGuestById(int id) {
        return guests.stream().filter(g -> g.getId() == id).findFirst();
    }
    public boolean updateGuest(int id, String name, String phone, String email) {
        Optional<Guest> o = findGuestById(id);
        if (o.isEmpty()) return false;
        Guest g = o.get();
        if (name != null) g.setName(name);
        if (phone != null) g.setPhone(phone);
        if (email != null) g.setEmail(email);
        return true;
    }
    public boolean deleteGuest(int id) {
        return guests.removeIf(g -> g.getId() == id);
    }

    // RESERVATION CRUD
    public Reservation createReservation(int roomId, int guestId, LocalDate from, LocalDate to) {
        Optional<Room> ro = findRoomById(roomId);
        Optional<Guest> go = findGuestById(guestId);
        if (ro.isEmpty() || go.isEmpty()) return null;
        Room room = ro.get();
        if (!room.isAvailable()) return null;
        Reservation res = new Reservation(roomId, guestId, from, to);
        reservations.add(res);
        room.setAvailable(false);
        return res;
    }
    public List<Reservation> listReservations() { return new ArrayList<>(reservations); }
    public Optional<Reservation> findReservationById(int id) {
        return reservations.stream().filter(r -> r.getId() == id).findFirst();
    }
    public boolean cancelReservation(int id) {
        Optional<Reservation> o = findReservationById(id);
        if (o.isEmpty()) return false;
        Reservation r = o.get();
        // mark room available
        findRoomById(r.getRoomId()).ifPresent(room -> room.setAvailable(true));
        return reservations.remove(r);
    }
}
